# M31 Capital Investment Scoring Framework - Google Sheets Guide

## Overview
This guide contains the complete M31 Capital Investment Scoring Framework extracted from the PDF, structured for easy import into Google Sheets with automated calculations.

## Framework Structure

### Core Categories and Weights
- **Team (25%)** - Team's ability to execute
- **Technology (20%)** - Technological foundation and blockchain implementation
- **Market Opportunity (20%)** - Market size, growth, and competitive dynamics
- **Blockchain Factors (15%)** - Decentralization-specific considerations
- **Business Model & Traction (15%)** - Revenue generation and market validation
- **Risk & Exit Potential (5%)** - Risk assessment and exit likelihood

### Scoring Scale (0-5)
- **5 - Exceptional**: Best-in-class performance
- **4 - Strong**: Exceeds expectations
- **3 - Average**: Meets expectations
- **2 - Below Average**: Addressable issues
- **1 - Weak**: Significant concerns
- **0 - Poor**: Poor or nonexistent

### Decision Thresholds
- **≥80**: Strong Buy - Exceptional opportunity with minimal risks
- **60-79**: Consider Investment - Promising but requires further diligence
- **40-59**: Hold - Significant concerns; monitor for improvements
- **<40**: Pass - High risk or insufficient potential

## Google Sheets Setup

### Files Provided
1. **M31_Investment_Scoring_Framework.csv** - Main framework with formulas
2. **M31_Category_Overview.csv** - Category descriptions and weights
3. **M31_Scoring_Guidelines.csv** - Scoring criteria reference
4. **M31_Decision_Thresholds.csv** - Investment decision guidelines
5. **M31_Subcategory_Definitions.csv** - Detailed subcategory definitions

### Import Instructions
1. Open Google Sheets and create a new spreadsheet
2. Import `M31_Investment_Scoring_Framework.csv` as the main sheet
3. Create additional sheets for reference materials
4. Apply formatting (borders, colors, conditional formatting)

### Formula Setup
The framework uses these key formulas:

**Category Score Calculation:**
```
=AVERAGE(C2:C5)  // For Team category
=AVERAGE(C6:C9)  // For Technology category
// Continue for each category
```

**Weighted Score Calculation:**
```
=D2*0.25  // Team weighted score (25%)
=D6*0.20  // Technology weighted score (20%)
// Continue for each category
```

**Total Score:**
```
=SUM(E2:E25)  // Sum of all weighted scores
```

## Framework Details

### Team (25% weight)
- **Team Experience**: Industry experience in blockchain/tech/startups
- **Track Record**: Past successes in founding or scaling businesses
- **Technical Expertise**: Blockchain development and engineering skills
- **Team Cohesion**: Collaboration, complementary skills, aligned vision

### Technology (20% weight)
- **Innovation**: Technology novelty compared to existing solutions
- **Scalability**: Ability to handle growth in users/transactions/data
- **Security**: Codebase robustness and vulnerability defenses
- **Technical Feasibility**: Likelihood of timely solution delivery

### Market Opportunity (20% weight)
- **Market Size**: Total and serviceable addressable market
- **Market Growth**: Projected 5-10 year growth rate
- **Competitive Landscape**: Differentiation and barriers to entry
- **Customer Fit**: Product alignment with customer needs/pain points

### Blockchain Factors (15% weight)
- **Decentralization Value**: Blockchain value vs centralized alternatives
- **Tokenomics**: Token design, incentives, and economic model
- **Network Effects**: Benefits from growing user adoption
- **Regulatory Compliance**: Alignment with blockchain regulations

### Business Model & Traction (15% weight)
- **Revenue Model**: Monetization strategy clarity and sustainability
- **Traction**: User adoption, partnerships, or early revenue evidence
- **Go-to-Market Strategy**: Customer acquisition and retention plan
- **Unit Economics**: Cost and revenue per user/transaction profitability

### Risk & Exit Potential (5% weight)
- **Execution Risk**: Operational, technical, or market challenges
- **Regulatory Risk**: Adverse regulatory changes exposure
- **Exit Potential**: Acquisition, IPO, or liquidity event likelihood
- **Macro Risk**: Sensitivity to macroeconomic factors

## Example Calculation
From the PDF example:
- Team: (4+3+5+4)/4 = 4.0 × 25% = 10.0
- Technology: (4+3+4+4)/4 = 3.75 × 20% = 7.5
- Market Opportunity: (5+4+3+4)/4 = 4.0 × 20% = 8.0
- Blockchain Factors: (4+3+4+3)/4 = 3.5 × 15% = 5.25
- Business Model: (3+2+3+3)/4 = 2.75 × 15% = 4.13
- Risk & Exit: (3+2+4+3)/4 = 3.0 × 5% = 1.5

**Total Score: 36.38/100 → HOLD**

## Usage Tips
1. Score each subcategory based on thorough due diligence
2. Use the subcategory definitions as scoring guidance
3. Review category scores for reasonableness
4. Consider the decision thresholds in context of portfolio strategy
5. Document rationale for scores to support decision-making

---
*This framework ensures a disciplined, data-driven approach to evaluating startups while accounting for unique risks and opportunities in the blockchain sector.*